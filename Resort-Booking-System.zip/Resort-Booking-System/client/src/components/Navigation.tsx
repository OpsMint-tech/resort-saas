import { Link, useLocation } from "wouter";
import { Button } from "./ui/button";
import { User, LogOut, LayoutDashboard, Hotel } from "lucide-react";
import { mockUser } from "@/lib/mock-data";
import { useState } from "react";

export function Navigation() {
  const [location] = useLocation();
  // Simulating logged in state for mockup purposes
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const userRole = isLoggedIn ? mockUser.role : null;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2 group">
            <Hotel className="h-8 w-8 text-primary group-hover:text-accent transition-colors" />
            <span className="font-serif text-2xl font-bold text-primary">LuxeStays</span>
          </a>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <Link href="/"><a className={`transition-colors hover:text-primary ${location === '/' ? 'text-primary' : 'text-muted-foreground'}`}>Destinations</a></Link>
          <Link href="/offers"><a className="text-muted-foreground hover:text-primary transition-colors">Special Offers</a></Link>
          <Link href="/experiences"><a className="text-muted-foreground hover:text-primary transition-colors">Experiences</a></Link>
        </nav>

        <div className="flex items-center gap-4">
          {!isLoggedIn ? (
            <>
              <Button variant="ghost" asChild onClick={() => setIsLoggedIn(true)}>
                <Link href="/login">Log In</Link>
              </Button>
              <Button className="bg-primary text-white hover:bg-primary/90" asChild onClick={() => setIsLoggedIn(true)}>
                <Link href="/register">Sign Up</Link>
              </Button>
            </>
          ) : (
            <div className="flex items-center gap-4">
              {userRole === 'admin' && (
                <Button variant="outline" size="sm" asChild>
                  <Link href="/admin/dashboard"><LayoutDashboard className="h-4 w-4 mr-2" /> Admin</Link>
                </Button>
              )}
              {userRole === 'owner' && (
                <Button variant="outline" size="sm" asChild>
                  <Link href="/owner/dashboard"><LayoutDashboard className="h-4 w-4 mr-2" /> Owner Portal</Link>
                </Button>
              )}
              {userRole === 'user' && (
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/my-bookings">My Bookings</Link>
                </Button>
              )}
              <Button variant="ghost" size="icon" onClick={() => setIsLoggedIn(false)}>
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
