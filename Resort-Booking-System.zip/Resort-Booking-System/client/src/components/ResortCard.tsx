import { Card, CardContent, CardFooter } from "./ui/card";
import { Button } from "./ui/button";
import { Link } from "wouter";
import { MapPin, Star } from "lucide-react";

interface Resort {
  id: number;
  name: string;
  location: string;
  pricePerNight: number;
  images: string[];
  rating: number;
}

export function ResortCard({ resort }: { resort: Resort }) {
  return (
    <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300 group rounded-xl">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={resort.images[0]} 
          alt={resort.name} 
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-700 ease-in-out"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm">
          <Star className="h-4 w-4 fill-accent text-accent" />
          <span className="text-sm font-semibold text-primary">{resort.rating}</span>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-serif text-xl font-bold text-primary line-clamp-1">{resort.name}</h3>
        </div>
        <div className="flex items-center text-muted-foreground mb-4">
          <MapPin className="h-4 w-4 mr-1.5 opacity-70" />
          <span className="text-sm">{resort.location}</span>
        </div>
        <div className="flex items-end gap-1">
          <span className="text-2xl font-bold text-primary">${resort.pricePerNight}</span>
          <span className="text-sm text-muted-foreground mb-1">/ night</span>
        </div>
      </CardContent>
      <CardFooter className="px-6 pb-6 pt-0">
        <Button asChild className="w-full bg-primary hover:bg-primary/90 text-white rounded-lg">
          <Link href={`/resorts/${resort.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
