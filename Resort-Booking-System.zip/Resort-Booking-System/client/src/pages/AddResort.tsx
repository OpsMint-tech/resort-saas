import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { UploadCloud, ArrowLeft, PlusCircle } from "lucide-react";
import { Link } from "wouter";

export default function AddResort() {
  return (
    <div className="min-h-screen flex flex-col bg-muted/20">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <Button variant="ghost" className="mb-4 -ml-4 text-muted-foreground" asChild>
            <Link href="/owner/dashboard"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard</Link>
          </Button>
          <h1 className="font-serif text-3xl font-bold text-primary mb-1">Add New Resort</h1>
          <p className="text-muted-foreground">List your property on LuxeStays. It will be reviewed by an administrator before going live.</p>
        </div>

        <form onSubmit={(e) => e.preventDefault()} className="space-y-8">
          <Card className="border-border/50 shadow-sm">
            <CardContent className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-semibold">Basic Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Property Name</Label>
                    <Input id="name" placeholder="E.g. Azure Horizon Resort" className="h-11" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input id="location" placeholder="E.g. Maldives" className="h-11" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Describe what makes your property unique..." className="min-h-[120px] resize-none" />
                </div>
                
                <div className="space-y-2 max-w-sm">
                  <Label htmlFor="price">Price Per Night (USD)</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <Input id="price" type="number" placeholder="0.00" className="h-11 pl-8" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-sm">
            <CardContent className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-semibold">Property Images</h3>
                <p className="text-sm text-muted-foreground mb-4">Upload high-quality images of your resort to attract more guests.</p>
                
                <div className="border-2 border-dashed border-border/60 rounded-xl p-12 flex flex-col items-center justify-center bg-muted/10 hover:bg-muted/30 transition-colors cursor-pointer text-center">
                  <UploadCloud className="h-12 w-12 text-primary mb-4" />
                  <h4 className="text-lg font-medium text-primary mb-1">Click to upload or drag and drop</h4>
                  <p className="text-sm text-muted-foreground">SVG, PNG, JPG or GIF (max. 5MB)</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                   {/* Placeholder for uploaded images */}
                   <div className="aspect-square rounded-lg border bg-muted flex items-center justify-center">
                      <PlusCircle className="h-6 w-6 text-muted-foreground" />
                   </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Button variant="outline" className="h-12 px-8" asChild>
              <Link href="/owner/dashboard">Cancel</Link>
            </Button>
            <Button className="h-12 px-8 bg-primary hover:bg-primary/90 text-lg" asChild>
               <Link href="/owner/dashboard">Submit for Review</Link>
            </Button>
          </div>
        </form>
      </main>
      <Footer />
    </div>
  );
}
