import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Building2, CircleDollarSign, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import { mockResorts } from "@/lib/mock-data";

export default function AdminDashboard() {
  const pendingResorts = [
    { id: 4, name: "Sunset Paradise Villa", location: "Bali, Indonesia", owner: "John Smith", date: "2024-10-22" }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-muted/20">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-primary mb-1">Global Dashboard</h1>
          <p className="text-muted-foreground">Platform-wide overview and administrative controls.</p>
        </div>

        {/* Global Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-border/50 shadow-sm bg-primary text-primary-foreground">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-primary-foreground/80">Global Sales</CardTitle>
              <CircleDollarSign className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">$2.4M</div>
              <p className="text-xs text-primary-foreground/60 mt-1">Total platform volume</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Platform Fee Revenue</CardTitle>
              <CircleDollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">$360K</div>
              <p className="text-xs text-green-600 mt-1">15% commission rate</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">12.5K</div>
              <p className="text-xs text-muted-foreground mt-1">+420 this month</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Resorts</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">845</div>
              <p className="text-xs text-amber-600 mt-1 flex items-center"><AlertCircle className="h-3 w-3 mr-1"/> 12 pending approval</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="approvals" className="space-y-6">
          <TabsList className="bg-card border border-border/50 p-1 rounded-xl">
            <TabsTrigger value="approvals" className="rounded-lg px-6">Resort Approvals</TabsTrigger>
            <TabsTrigger value="ledger" className="rounded-lg px-6">Master Ledger</TabsTrigger>
            <TabsTrigger value="users" className="rounded-lg px-6">User Management</TabsTrigger>
          </TabsList>

          <TabsContent value="approvals" className="space-y-4">
            <Card className="border-border/50 shadow-sm">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Pending Resort Applications</CardTitle>
                <CardDescription>Review and approve new property listings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-hidden">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-muted/50 text-muted-foreground font-medium border-b">
                      <tr>
                        <th className="px-6 py-4">Property Name</th>
                        <th className="px-6 py-4">Location</th>
                        <th className="px-6 py-4">Owner</th>
                        <th className="px-6 py-4">Submitted</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {pendingResorts.map((resort) => (
                        <tr key={resort.id} className="bg-card hover:bg-muted/20 transition-colors">
                          <td className="px-6 py-4 font-medium text-primary">{resort.name}</td>
                          <td className="px-6 py-4 text-muted-foreground">{resort.location}</td>
                          <td className="px-6 py-4">{resort.owner}</td>
                          <td className="px-6 py-4 text-muted-foreground">{resort.date}</td>
                          <td className="px-6 py-4 text-right space-x-2">
                            <Button size="sm" variant="outline" className="text-green-600 border-green-200 hover:bg-green-50 hover:text-green-700">
                              <CheckCircle className="h-4 w-4 mr-1" /> Approve
                            </Button>
                            <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700">
                              <XCircle className="h-4 w-4 mr-1" /> Reject
                            </Button>
                          </td>
                        </tr>
                      ))}
                      {mockResorts.slice(0, 2).map((resort) => (
                         <tr key={resort.id} className="bg-card">
                          <td className="px-6 py-4 font-medium text-primary">{resort.name}</td>
                          <td className="px-6 py-4 text-muted-foreground">{resort.location}</td>
                          <td className="px-6 py-4">System Demo</td>
                          <td className="px-6 py-4 text-muted-foreground">Approved</td>
                          <td className="px-6 py-4 text-right">
                             <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Active</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ledger">
            <Card className="border-border/50 shadow-sm p-12 text-center text-muted-foreground">
              Master Ledger view coming soon.
            </Card>
          </TabsContent>
          <TabsContent value="users">
            <Card className="border-border/50 shadow-sm p-12 text-center text-muted-foreground">
              User Management view coming soon.
            </Card>
          </TabsContent>
        </Tabs>

      </main>
    </div>
  );
}
