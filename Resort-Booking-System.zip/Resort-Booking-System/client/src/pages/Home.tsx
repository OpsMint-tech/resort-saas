import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ResortCard } from "@/components/ResortCard";
import { mockResorts } from "@/lib/mock-data";
import { Calendar, Users, Search, ArrowRight } from "lucide-react";

export default function Home() {
  const featuredResorts = mockResorts.slice(0, 3);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-primary/40 z-10 mix-blend-multiply" />
          <img 
            src="/src/assets/images/resort-1.jpg" 
            alt="Luxury Resort" 
            className="w-full h-full object-cover object-center"
          />
        </div>
        
        <div className="relative z-20 container mx-auto px-4 text-center mt-16">
          <span className="inline-block py-1 px-3 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white text-sm font-medium tracking-widest uppercase mb-6">
            The Art of Hospitality
          </span>
          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
            Discover Your <br/><span className="text-accent italic">Perfect</span> Escape
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-12 drop-shadow-md font-light">
            Curated luxury experiences at the world's most breathtaking destinations. Book your next unforgettable stay with LuxeStays.
          </p>

          {/* Search Bar - Mockup */}
          <div className="max-w-4xl mx-auto bg-white rounded-2xl p-3 shadow-2xl flex flex-col md:flex-row gap-3">
            <div className="flex-1 flex items-center bg-muted/50 rounded-xl px-4 py-3 border border-border/50">
              <Search className="h-5 w-5 text-muted-foreground mr-3" />
              <input 
                type="text" 
                placeholder="Where do you want to go?" 
                className="bg-transparent border-none outline-none w-full text-foreground placeholder:text-muted-foreground"
              />
            </div>
            <div className="flex-1 flex items-center bg-muted/50 rounded-xl px-4 py-3 border border-border/50">
              <Calendar className="h-5 w-5 text-muted-foreground mr-3" />
              <input 
                type="text" 
                placeholder="Check-in - Check-out" 
                className="bg-transparent border-none outline-none w-full text-foreground placeholder:text-muted-foreground"
                readOnly
              />
            </div>
            <div className="flex-1 flex items-center bg-muted/50 rounded-xl px-4 py-3 border border-border/50">
              <Users className="h-5 w-5 text-muted-foreground mr-3" />
              <select className="bg-transparent border-none outline-none w-full text-foreground appearance-none">
                <option>2 Guests, 1 Room</option>
                <option>1 Guest, 1 Room</option>
                <option>4 Guests, 2 Rooms</option>
              </select>
            </div>
            <Button className="h-auto py-4 px-8 bg-accent hover:bg-accent/90 text-primary-foreground font-semibold rounded-xl whitespace-nowrap">
              Search
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div className="max-w-2xl">
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4">Featured Collections</h2>
              <p className="text-muted-foreground text-lg">Handpicked properties that define the pinnacle of luxury and comfort.</p>
            </div>
            <Button variant="outline" className="rounded-full hidden md:flex items-center group border-primary/20 hover:border-primary">
              View All Resorts <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredResorts.map(resort => (
              <ResortCard key={resort.id} resort={resort} />
            ))}
          </div>
          
          <div className="mt-12 text-center md:hidden">
             <Button variant="outline" className="rounded-full w-full max-w-sm">
              View All Resorts
            </Button>
          </div>
        </div>
      </section>

      {/* Experience Banner */}
      <section className="py-24 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-serif text-4xl md:text-5xl font-bold mb-6 leading-tight">Elevate Your Travel Experience</h2>
              <p className="text-primary-foreground/80 text-lg mb-8 leading-relaxed">
                Beyond exquisite accommodations, we offer bespoke experiences tailored to your desires. From private yacht charters to exclusive culinary events, let us craft the perfect itinerary for your stay.
              </p>
              <Button size="lg" className="bg-accent text-primary hover:bg-accent/90 rounded-full px-8">
                Explore Experiences
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img src="/src/assets/images/resort-2.jpg" alt="Experience 1" className="rounded-2xl h-64 w-full object-cover mt-8" />
              <img src="/src/assets/images/resort-3.jpg" alt="Experience 2" className="rounded-2xl h-64 w-full object-cover" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
