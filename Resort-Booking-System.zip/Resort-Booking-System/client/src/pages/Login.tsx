import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Hotel } from "lucide-react";

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="max-w-md w-full bg-card rounded-2xl shadow-xl p-8 border border-border/50">
        <div className="flex justify-center mb-8">
          <Link href="/">
            <a className="flex items-center gap-2 group">
              <Hotel className="h-8 w-8 text-primary group-hover:text-accent transition-colors" />
              <span className="font-serif text-2xl font-bold text-primary">LuxeStays</span>
            </a>
          </Link>
        </div>
        
        <div className="text-center mb-8">
          <h1 className="font-serif text-3xl font-bold text-primary mb-2">Welcome Back</h1>
          <p className="text-muted-foreground">Sign in to manage your bookings.</p>
        </div>

        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input id="email" type="email" placeholder="name@example.com" className="h-12" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              <a href="#" className="text-sm text-accent hover:underline">Forgot password?</a>
            </div>
            <Input id="password" type="password" placeholder="••••••••" className="h-12" />
          </div>

          <Button type="button" className="w-full h-12 text-lg bg-primary hover:bg-primary/90" asChild>
             {/* Simulating login redirect to dashboard for mockup */}
            <Link href="/">Sign In</Link>
          </Button>
        </form>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          Don't have an account?{" "}
          <Link href="/register"><a className="text-primary font-semibold hover:text-accent transition-colors">Create one</a></Link>
        </div>
        
        <div className="mt-8 pt-6 border-t flex justify-center gap-4">
           <Button variant="outline" size="sm" asChild className="w-full text-xs">
              <Link href="/owner/dashboard">Demo Owner</Link>
           </Button>
           <Button variant="outline" size="sm" asChild className="w-full text-xs">
              <Link href="/admin/dashboard">Demo Admin</Link>
           </Button>
        </div>
      </div>
    </div>
  );
}
