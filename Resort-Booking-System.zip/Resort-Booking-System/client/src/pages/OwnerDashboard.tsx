import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building, DollarSign, TrendingUp, CalendarDays, Plus, MoreHorizontal } from "lucide-react";
import { mockResorts } from "@/lib/mock-data";

export default function OwnerDashboard() {
  const myResorts = mockResorts.slice(0, 2);
  
  const recentTransactions = [
    { id: "TX-1", customer: "Alice Smith", date: "2024-10-15", amount: 1500, status: "completed" },
    { id: "TX-2", customer: "Robert Jones", date: "2024-10-18", amount: 3200, status: "pending" },
    { id: "TX-3", customer: "Eva Brown", date: "2024-10-20", amount: 850, status: "completed" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-muted/20">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="font-serif text-3xl font-bold text-primary mb-1">Owner Portal</h1>
            <p className="text-muted-foreground">Manage your properties and track revenue.</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90">
            <Plus className="h-4 w-4 mr-2" /> Add New Resort
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">$124,500</div>
              <p className="text-xs text-green-600 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" /> +14% from last month
              </p>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Payouts</CardTitle>
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">$12,400</div>
              <p className="text-xs text-muted-foreground mt-1">Expected within 7 days</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Properties</CardTitle>
              <Building className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">2</div>
              <p className="text-xs text-muted-foreground mt-1">1 property pending review</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Properties List */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="font-serif text-2xl font-bold text-primary">My Resorts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {myResorts.map(resort => (
                <Card key={resort.id} className="overflow-hidden border-border/50">
                  <div className="aspect-video relative">
                    <img src={resort.images[0]} alt={resort.name} className="w-full h-full object-cover" />
                    <div className="absolute top-3 right-3">
                      <Badge variant="secondary" className="bg-white/90 backdrop-blur-sm shadow-sm">{resort.status.toUpperCase()}</Badge>
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <h3 className="font-bold text-lg text-primary mb-1 line-clamp-1">{resort.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{resort.description}</p>
                    <div className="flex justify-between items-center pt-4 border-t border-border/50">
                       <div className="font-medium text-primary">${resort.pricePerNight} <span className="text-xs text-muted-foreground font-normal">/ night</span></div>
                       <Button variant="ghost" size="sm" className="h-8">Edit</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="lg:col-span-1">
             <Card className="border-border/50 shadow-sm h-full">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Money Flow</CardTitle>
                <CardDescription>Recent booking transactions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {recentTransactions.map(tx => (
                  <div key={tx.id} className="flex justify-between items-center">
                    <div>
                      <p className="font-medium text-sm text-primary">{tx.customer}</p>
                      <p className="text-xs text-muted-foreground">{tx.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-sm text-primary">+${tx.amount}</p>
                      <Badge variant="outline" className={`text-[10px] uppercase px-1.5 py-0 ${tx.status === 'completed' ? 'text-green-600 border-green-200 bg-green-50' : 'text-amber-600 border-amber-200 bg-amber-50'}`}>
                        {tx.status}
                      </Badge>
                    </div>
                  </div>
                ))}
                
                <Button variant="outline" className="w-full mt-4">View All Transactions</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
