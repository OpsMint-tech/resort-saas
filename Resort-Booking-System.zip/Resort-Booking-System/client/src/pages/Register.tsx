import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Hotel } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function Register() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4 py-12">
      <div className="max-w-md w-full bg-card rounded-2xl shadow-xl p-8 border border-border/50">
        <div className="flex justify-center mb-8">
          <Link href="/">
            <a className="flex items-center gap-2 group">
              <Hotel className="h-8 w-8 text-primary group-hover:text-accent transition-colors" />
              <span className="font-serif text-2xl font-bold text-primary">LuxeStays</span>
            </a>
          </Link>
        </div>
        
        <div className="text-center mb-8">
          <h1 className="font-serif text-3xl font-bold text-primary mb-2">Create an Account</h1>
          <p className="text-muted-foreground">Join our exclusive community.</p>
        </div>

        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          <div className="space-y-2">
            <Label htmlFor="name">Full Name</Label>
            <Input id="name" placeholder="John Doe" className="h-12" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input id="email" type="email" placeholder="name@example.com" className="h-12" />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="••••••••" className="h-12" />
          </div>

          <div className="space-y-3 pt-2">
            <Label>I am signing up as:</Label>
            <RadioGroup defaultValue="user" className="flex gap-4">
              <div className="flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer bg-muted/20 data-[state=checked]:border-primary data-[state=checked]:bg-primary/5">
                <RadioGroupItem value="user" id="r1" />
                <Label htmlFor="r1" className="cursor-pointer">Guest</Label>
              </div>
              <div className="flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer bg-muted/20 data-[state=checked]:border-primary data-[state=checked]:bg-primary/5">
                <RadioGroupItem value="owner" id="r2" />
                <Label htmlFor="r2" className="cursor-pointer">Resort Owner</Label>
              </div>
            </RadioGroup>
          </div>

          <Button type="button" className="w-full h-12 text-lg bg-primary hover:bg-primary/90 mt-6" asChild>
            <Link href="/login">Create Account</Link>
          </Button>
        </form>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          Already have an account?{" "}
          <Link href="/login"><a className="text-primary font-semibold hover:text-accent transition-colors">Sign in</a></Link>
        </div>
      </div>
    </div>
  );
}
