import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { mockResorts } from "@/lib/mock-data";
import { MapPin, Star, Wifi, Coffee, Car, Wind, CheckCircle2 } from "lucide-react";

export default function ResortDetails() {
  const { id } = useParams();
  const resort = mockResorts.find(r => r.id === Number(id)) || mockResorts[0];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header Gallery */}
      <div className="relative h-[60vh] w-full bg-muted">
        <img 
          src={resort.images[0]} 
          alt={resort.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      <div className="container mx-auto px-4 -mt-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-card rounded-2xl p-8 shadow-xl border border-border/50">
              <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
                <div>
                  <h1 className="font-serif text-4xl font-bold text-primary mb-2">{resort.name}</h1>
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="h-5 w-5 mr-2 text-accent" />
                    <span className="text-lg">{resort.location}</span>
                  </div>
                </div>
                <div className="flex items-center bg-secondary px-4 py-2 rounded-xl">
                  <Star className="h-5 w-5 fill-accent text-accent mr-2" />
                  <span className="text-lg font-bold text-primary">{resort.rating} <span className="text-muted-foreground text-sm font-normal">/ 5.0</span></span>
                </div>
              </div>

              <div className="prose max-w-none text-muted-foreground mt-8">
                <p className="text-lg leading-relaxed">{resort.description}</p>
                <p className="mt-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </div>
            </div>

            <div className="bg-card rounded-2xl p-8 shadow-md border border-border/50">
              <h2 className="font-serif text-2xl font-bold text-primary mb-6">Amenities</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {resort.amenities.map((amenity, i) => (
                  <div key={i} className="flex items-center text-muted-foreground">
                    <CheckCircle2 className="h-5 w-5 mr-3 text-accent" />
                    <span className="font-medium">{amenity}</span>
                  </div>
                ))}
                {/* Mock extra amenities */}
                <div className="flex items-center text-muted-foreground"><Wifi className="h-5 w-5 mr-3 text-accent" /><span className="font-medium">High-speed WiFi</span></div>
                <div className="flex items-center text-muted-foreground"><Coffee className="h-5 w-5 mr-3 text-accent" /><span className="font-medium">Room Service</span></div>
                <div className="flex items-center text-muted-foreground"><Car className="h-5 w-5 mr-3 text-accent" /><span className="font-medium">Valet Parking</span></div>
                <div className="flex items-center text-muted-foreground"><Wind className="h-5 w-5 mr-3 text-accent" /><span className="font-medium">Air Conditioning</span></div>
              </div>
            </div>
          </div>

          {/* Booking Widget */}
          <div className="lg:col-span-1">
            <div className="sticky top-28 bg-card rounded-2xl p-8 shadow-xl border border-border/50">
              <div className="flex items-end gap-2 mb-6 pb-6 border-b border-border/50">
                <span className="text-4xl font-bold text-primary">${resort.pricePerNight}</span>
                <span className="text-muted-foreground mb-1">/ night</span>
              </div>

              <div className="space-y-4 mb-8">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 border rounded-xl bg-muted/30">
                    <span className="block text-xs text-muted-foreground uppercase font-semibold mb-1">Check-in</span>
                    <div className="font-medium">Oct 24, 2024</div>
                  </div>
                  <div className="p-3 border rounded-xl bg-muted/30">
                    <span className="block text-xs text-muted-foreground uppercase font-semibold mb-1">Check-out</span>
                    <div className="font-medium">Oct 29, 2024</div>
                  </div>
                </div>
                <div className="p-3 border rounded-xl bg-muted/30">
                  <span className="block text-xs text-muted-foreground uppercase font-semibold mb-1">Guests</span>
                  <div className="font-medium">2 Adults, 1 Room</div>
                </div>
              </div>

              <div className="space-y-3 mb-8 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>${resort.pricePerNight} x 5 nights</span>
                  <span>${resort.pricePerNight * 5}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Taxes & Fees</span>
                  <span>${Math.round(resort.pricePerNight * 5 * 0.15)}</span>
                </div>
                <div className="flex justify-between font-bold text-primary pt-3 border-t text-lg">
                  <span>Total</span>
                  <span>${(resort.pricePerNight * 5) + Math.round(resort.pricePerNight * 5 * 0.15)}</span>
                </div>
              </div>

              <Button size="lg" className="w-full bg-primary hover:bg-primary/90 text-white rounded-xl text-lg h-14" asChild>
                <Link href="/login">Reserve Now</Link>
              </Button>
              <p className="text-center text-xs text-muted-foreground mt-4">You won't be charged yet</p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
