import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Search } from "lucide-react";
import { mockResorts } from "@/lib/mock-data";

export default function UserBookings() {
  const bookings = [
    {
      id: "B-1029",
      resort: mockResorts[0],
      checkIn: "2024-10-24",
      checkOut: "2024-10-29",
      status: "confirmed",
      totalPrice: 4887,
    },
    {
      id: "B-0982",
      resort: mockResorts[1],
      checkIn: "2024-12-10",
      checkOut: "2024-12-15",
      status: "pending",
      totalPrice: 6900,
    }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-muted/20">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="font-serif text-4xl font-bold text-primary mb-2">My Bookings</h1>
            <p className="text-muted-foreground">Manage your upcoming stays and review past trips.</p>
          </div>
          
          <div className="relative w-full md:w-auto">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
             <input 
               type="text" 
               placeholder="Search bookings..." 
               className="pl-10 pr-4 py-2 rounded-lg border border-border bg-white w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-primary/20"
             />
          </div>
        </div>

        <div className="space-y-6">
          {bookings.map(booking => (
            <Card key={booking.id} className="overflow-hidden border-border/50 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex flex-col md:flex-row">
                <div className="w-full md:w-64 h-48 md:h-auto shrink-0 relative">
                  <img src={booking.resort.images[0]} alt={booking.resort.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 p-6 flex flex-col justify-between">
                  <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-sm font-medium text-muted-foreground">#{booking.id}</span>
                        <Badge variant={booking.status === 'confirmed' ? 'default' : 'secondary'} className={booking.status === 'confirmed' ? 'bg-green-600/10 text-green-700 hover:bg-green-600/20' : ''}>
                          {booking.status.toUpperCase()}
                        </Badge>
                      </div>
                      <h3 className="font-serif text-2xl font-bold text-primary mb-1">{booking.resort.name}</h3>
                      <div className="flex items-center text-muted-foreground text-sm">
                        <MapPin className="h-4 w-4 mr-1" /> {booking.resort.location}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">${booking.totalPrice}</div>
                      <div className="text-sm text-muted-foreground">Total Paid</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2 bg-muted/50 px-4 py-2 rounded-lg">
                      <Calendar className="h-4 w-4 text-accent" />
                      <span className="font-medium">{new Date(booking.checkIn).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {new Date(booking.checkOut).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    </div>
                    <button className="text-primary font-medium hover:text-accent transition-colors">View Itinerary</button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
